import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ownerRequestRejection } from '../lib/dfy-policy.js';
import { createWorkerToken, admitWorkerRequest, WORKER_TOKEN_HEADER } from '../lib/worker-auth.js';
import { loadManaged, fakeSubprocess, testConfig } from './load-managed.mjs';

const plugin = await loadManaged();

for (const stderr of ['target closed after click', 'ECONNREFUSED', 'DevTools port timeout', 'task space not found: 7']) {
  test(`one submission, unknown result, no replay: ${stderr}`, async () => {
    const subprocess = fakeSubprocess({ stderr });
    let built = 0;
    const result = await plugin.runWithStaleSpaceRetry({ subprocess }, testConfig(), {}, () => { built++; return 'click();'; });
    assert.equal(subprocess.calls, 1);
    assert.equal(built, 1);
    assert.equal(result.executionState, 'unknown');
    assert.equal(result.retryable, false);
    assert.equal(result.code, 'EGO_EXECUTION_UNKNOWN');
  });
}

test('cancelled before submission starts no process and builds no script', async () => {
  const controller = new AbortController(); controller.abort();
  const subprocess = fakeSubprocess();
  const result = await plugin.runWithStaleSpaceRetry({ subprocess }, testConfig(), { signal: controller.signal }, () => assert.fail('must not build'));
  assert.equal(subprocess.calls, 0);
  assert.equal(result.executionState, 'not-started');
  assert.equal(result.cancelled, true);
});

test('cancel after submission is unknown even when stdout includes a success sentinel', async () => {
  const controller = new AbortController();
  const subprocess = fakeSubprocess({ stdout: '@@DSH_RESULT@@{"ok":true}\n', exitCode: 0,
    onSpawn: (options) => { assert.equal(options.signal, controller.signal); controller.abort(); } });
  const result = await plugin.runWithStaleSpaceRetry({ subprocess }, testConfig(), { signal: controller.signal }, () => 'click();');
  assert.equal(subprocess.calls, 1);
  assert.equal(result.executionState, 'unknown');
  assert.equal(result.cancelled, true);
});

test('timeout after start remains unknown and never falls through into a second process', async () => {
  const subprocess = fakeSubprocess({ done: Promise.reject(new Error('grace period timeout')) });
  const result = await plugin.runWithStaleSpaceRetry({ subprocess }, testConfig(), {}, () => 'click();');
  assert.equal(subprocess.calls, 1);
  assert.equal(result.executionState, 'unknown');
  assert.equal(result.timedOut, true);
});

test('native mutation tool throws typed unknown failure without replay', async () => {
  const subprocess = fakeSubprocess({ stderr: 'target closed after click' });
  const tools = [];
  plugin.registerActionTools({ subprocess }, testConfig(), (tool) => tools.push(tool));
  const click = tools.find((tool) => tool.name === 'ego_click');
  await assert.rejects(click.execute({ selector: '#submit', space: 'test-owned-space' }, {}), (error) => {
    assert.equal(error.code, 'EGO_EXECUTION_UNKNOWN');
    assert.equal(error.executionState, 'unknown');
    assert.equal(error.retryable, false);
    return true;
  });
  assert.equal(subprocess.calls, 1);
});

test('resident connection loss and rejected transport never fall back to one-shot replay', async () => {
  for (const rejected of [false, true]) {
    const subprocess = fakeSubprocess();
    let submissions = 0;
    const result = await plugin.runEgoScript(subprocess, 'click();', {}, { ...testConfig(), residentExecutor: true }, undefined, {
      ensureResidentTransport: () => ({ run: async () => {
        submissions++;
        if (rejected) throw new Error('resident stopped after submission');
        return { ok: false, error: 'target closed after click', stdout: '', stderr: '' };
      } })
    });
    assert.equal(submissions, 1);
    assert.equal(subprocess.calls, 0);
    assert.equal(result.ok, false);
  }
});

test('confirmed native output remains unchanged', async () => {
  const subprocess = fakeSubprocess({ stdout: '@@DSH_RESULT@@{"ok":true,"page":{"url":"http://127.0.0.1/test"}}\n', exitCode: 0 });
  const result = await plugin.runWithStaleSpaceRetry({ subprocess }, testConfig(), {}, () => 'read();');
  assert.equal(subprocess.calls, 1);
  assert.equal(result.ok, true);
  assert.equal(result.value.page.url, 'http://127.0.0.1/test');
});

test('login import is absent from the tool registry and direct CLI profile import is disabled', async () => {
  const tools = [];
  plugin.registerLoginImport({}, testConfig(), (tool) => tools.push(tool));
  assert.equal(tools.length, 0);
  const cli = await readFile(new URL('../runtime/ego-linux/bin/ego-browser.mjs', import.meta.url), 'utf8');
  assert.match(cli, /async function importChromeProfile\(\) \{\s*process\.stderr\.write\("LOGIN_IMPORT_DISABLED[^]*?return 1;/);
});

const owner = { admit: () => ({ peer: { principal: { kind: 'owner' } } }) };
const response = () => ({ statusCode: null, headers: {}, writeHead(status, headers) { this.statusCode = status; this.headers = headers; },
  setHeader(key, value) { this.headers[key] = value; }, end(body) { this.body = body; } });
function routeContext(connection) {
  const routes = [];
  const server = { register(route) { routes.push(route); return () => {}; } };
  return { routes, ctx: { get: (key) => key === 'connection' ? connection : key === 'webServer' ? server : undefined,
    effect: (callback) => callback(), inject: () => {} } };
}

test('owner admission rejects forged cookies, non-owner, ended peers, errors and missing connection', () => {
  const req = { headers: { cookie: 'dsh-auth-forged=anything' } };
  assert.equal(ownerRequestRejection(undefined, req), 403);
  assert.equal(ownerRequestRejection({ admit: () => ({ rejection: 401 }) }, req), 401);
  assert.equal(ownerRequestRejection({ admit: () => ({ peer: { principal: { kind: 'guest' } } }) }, req), 403);
  assert.equal(ownerRequestRejection({ admit: () => ({ peer: { principal: { kind: 'owner' }, signal: { aborted: true } } }) }, req), 403);
  assert.equal(ownerRequestRejection({ admit: () => { throw new Error('bad'); } }, req), 403);
  assert.equal(ownerRequestRejection(owner, req), null);
});

test('all cast HTTP handlers require actual owner admission before touching worker', async () => {
  const { ctx, routes } = routeContext({ admit: () => ({ rejection: 401 }) });
  plugin.initCastServer(ctx, testConfig(), {}, undefined);
  assert.ok(routes.length >= 10);
  for (const route of routes) {
    const res = response();
    await route.handler({ headers: { cookie: 'dsh-auth-forged=yes' } }, res);
    assert.equal(res.statusCode, 401, route.path);
  }
});

test('login-import HTTP remains disabled for authenticated owners', async () => {
  const { ctx, routes } = routeContext(owner);
  plugin.initCastServer(ctx, testConfig(), {}, undefined, () => assert.fail('must not open'), () => assert.fail('must not import'));
  const route = routes.find((route) => route.path === '/api/ego/login-import');
  const res = response();
  await route.handler({ method: 'POST', headers: {} }, res);
  assert.equal(res.statusCode, 403);
  assert.equal(JSON.parse(res.body).code, 'LOGIN_IMPORT_DISABLED');
});

test('settings get/set/check/install all reject forged-cookie requests before body processing', async () => {
  const { ctx, routes } = routeContext({ admit: () => ({ rejection: 401 }) });
  plugin.registerEgoBrowserGateway(ctx, { source: () => ({}) }, undefined);
  for (const method of ['get', 'set', 'ffmpeg-check', 'ffmpeg-install']) {
    const res = response();
    await routes[0].handler({ method: 'POST', url: `/ego/api/${method}`, headers: { cookie: 'dsh-auth-forged=x', 'content-type': 'application/json' } }, res);
    assert.equal(res.statusCode, 401);
  }
});

test('owner settings read remains usable', async () => {
  const { ctx, routes } = routeContext(owner);
  plugin.registerEgoBrowserGateway(ctx, { source: () => ({ chromePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' }) }, undefined);
  const res = response();
  const req = { method: 'POST', url: '/ego/api/get', headers: { host: '127.0.0.1:9000', origin: 'http://127.0.0.1:9000', 'content-type': 'application/json' },
    async *[Symbol.asyncIterator]() { yield Buffer.from('{}'); } };
  await routes[0].handler(req, res);
  assert.equal(res.statusCode, 200);
  assert.ok(JSON.parse(res.body));
});

test('Chrome sandbox guard covers configuration and inherited environment; dedicated path wins', async () => {
  for (const baseEnv of [ {}, { EGO_LINUX_EXTRA_ARGS: '--no-sandbox --disable-gpu-sandbox --lang=zh-CN', EGO_LINUX_CHROME: '/unsafe-wrapper' } ]) {
    const env = plugin.resolveEgoEnv({ ...testConfig(), chromeArgs: '--disable-setuid-sandbox --lang=zh-CN' }, { platform: 'darwin', baseEnv });
    assert.equal(env.EGO_LINUX_CHROME, testConfig().chromePath);
    assert.doesNotMatch(env.EGO_LINUX_EXTRA_ARGS, /--(?:no-sandbox|disable-setuid-sandbox|disable-gpu-sandbox)/);
    assert.match(env.EGO_LINUX_EXTRA_ARGS, /--lang=zh-CN/);
  }
  const wrapper = await readFile(new URL('../bin/ego-chrome-wrapper.sh', import.meta.url), 'utf8');
  assert.doesNotMatch(wrapper, /exec[^\n]*--no-sandbox/);
  const runtime = await readFile(new URL('../runtime/ego-linux/src/chrome.mjs', import.meta.url), 'utf8');
  assert.match(runtime, /"--no-sandbox", "--disable-sandbox", "--disable-setuid-sandbox"/);
});

test('real loopback HTTP: worker denies untrusted state/action/stream requests, owner host proxy succeeds without exposing token', async () => {
  const stateRoot = await mkdtemp(join(tmpdir(), 'dfy-ego-worker-test-'));
  const previous = process.env.XDG_STATE_HOME;
  const previousOverride = process.env.EGO_LINUX_STATE_DIR;
  process.env.XDG_STATE_HOME = stateRoot;
  delete process.env.EGO_LINUX_STATE_DIR;
  const token = createWorkerToken();
  assert.notEqual(token, createWorkerToken());
  let accepted = 0;
  let mutationCount = 0;
  const worker = createServer((req, res) => {
    if (!admitWorkerRequest(req, res, token)) return;
    accepted++;
    if (req.url === '/api/input') mutationCount++;
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ ok: true, workerOk: true, mutationCount }));
  });
  let host;
  try {
    await new Promise((resolve) => worker.listen(0, '127.0.0.1', resolve));
    const port = worker.address().port;
    const workerUrl = `http://127.0.0.1:${port}`;
    for (const path of ['/api/health', '/api/spaces', '/api/snapshot', '/api/stream', '/api/input', '/api/config', '/api/close', '/api/watch/start', '/api/video/stream']) {
      for (const headers of [{}, { [WORKER_TOKEN_HEADER]: '0'.repeat(64) }]) {
        const result = await fetch(workerUrl + path, { method: path === '/api/input' ? 'POST' : 'GET', headers });
        assert.equal(result.status, 403, path);
        assert.equal(JSON.parse(await result.text()).error, 'worker-auth-required');
      }
    }
    assert.equal(accepted, 0);
    const preflight = await fetch(workerUrl + '/api/stream', { method: 'OPTIONS', headers: { origin: 'https://untrusted.example' } });
    assert.equal(preflight.status, 204);
    assert.equal(await preflight.text(), '');
    assert.equal(preflight.headers.get('access-control-allow-origin'), null);
    const stateDir = join(stateRoot, 'ego-lite-linux');
    await mkdir(stateDir);
    await writeFile(join(stateDir, 'ego-cast.json'), JSON.stringify({ port, pid: process.pid, token }), { mode: 0o600 });
    const proxyPlugin = await loadManaged({ fetchImpl: fetch });
    const admission = { admit: (req) => req.headers['x-test-owner'] === 'yes'
      ? { peer: { principal: { kind: 'owner' } } } : { rejection: 403 } };
    const { ctx, routes } = routeContext(admission);
    proxyPlugin.initCastServer(ctx, testConfig(), {}, undefined);
    host = createServer((req, res) => {
      const route = routes.find((candidate) => candidate.path === req.url);
      if (!route) { res.writeHead(404); res.end(); return; }
      Promise.resolve(route.handler(req, res)).catch(() => { res.writeHead(500); res.end(); });
    });
    await new Promise((resolve) => host.listen(0, '127.0.0.1', resolve));
    const hostUrl = `http://127.0.0.1:${host.address().port}`;
    const denied = await fetch(hostUrl + '/api/ego/health', { headers: { cookie: 'dsh-auth-forged=x' } });
    assert.equal(denied.status, 403);
    assert.equal(accepted, 0);
    const health = await fetch(hostUrl + '/api/ego/health', { headers: { 'x-test-owner': 'yes' } });
    const healthText = await health.text();
    assert.equal(health.status, 200);
    assert.equal(JSON.parse(healthText).workerOk, true);
    assert.ok(!healthText.includes(token));
    const action = await fetch(hostUrl + '/api/ego/input', { method: 'POST',
      headers: { 'x-test-owner': 'yes', 'content-type': 'application/json' }, body: '{"type":"click"}' });
    const actionText = await action.text();
    assert.equal(action.status, 200);
    assert.equal(JSON.parse(actionText).mutationCount, 1);
    assert.equal(mutationCount, 1);
    assert.ok(!actionText.includes(token));
    // Worker source uses this same admission guard before route dispatch.
    const source = await readFile(new URL('../bin/ego-cast-worker.mjs', import.meta.url), 'utf8');
    assert.match(source, /createServer\(async \(req, res\) => \{\s*if \(!admitWorkerRequest\(req, res, workerToken\)\) return;\s*const url/);
    assert.match(source, /token: workerToken\s*\}, null, 2\), \{ mode: 0o600 \}\)/);
    assert.doesNotMatch(source.slice(source.indexOf('console.log(`${SENTINEL}')), /token: workerToken/);
  } finally {
    if (host) await new Promise((resolve) => host.close(resolve));
    await new Promise((resolve) => worker.close(resolve));
    if (previous === undefined) delete process.env.XDG_STATE_HOME; else process.env.XDG_STATE_HOME = previous;
    if (previousOverride === undefined) delete process.env.EGO_LINUX_STATE_DIR; else process.env.EGO_LINUX_STATE_DIR = previousOverride;
    await rm(stateRoot, { recursive: true, force: true });
  }
});
