import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

// Evaluate only plugin JS against a fake DSH surface. Never start a browser,
// execute the vendored CLI, use GUI, or load an active profile.
export async function loadManaged({ fetchImpl } = {}) {
  const chain = new Proxy(function () {}, {
    get: (_target, key) => key === 'then' ? undefined : chain,
    apply: () => chain
  });
  const context = vm.createContext({
    process, console, Buffer, URL, URLSearchParams, AbortController, AbortSignal,
    setTimeout, clearTimeout, setInterval, clearInterval, TextDecoder, TextEncoder,
    fetch: fetchImpl ?? (() => { throw new Error('Network forbidden in managed policy tests'); })
  });
  const modules = new Map();
  async function load(url) {
    if (modules.has(url)) return modules.get(url);
    const source = await readFile(new URL(url), 'utf8');
    const module = new vm.SourceTextModule(source, {
      context, identifier: url, initializeImportMeta: (meta) => { meta.url = url; },
      importModuleDynamically: async (specifier) => {
        if (!specifier.startsWith('node:')) throw new Error('Unexpected dynamic import');
        return import(specifier);
      }
    });
    modules.set(url, module);
    await module.link(async (specifier, referencing) => {
      if (specifier.startsWith('.')) return load(new URL(specifier, referencing.identifier).href);
      let values;
      if (specifier === '@deepseek-ai/dsh-tools') values = { defineTool: (tool) => tool };
      else if (specifier === '@deepseek-ai/schemastery') values = { default: chain };
      else if (specifier.startsWith('node:')) values = await import(specifier);
      else throw new Error(`Unexpected package import: ${specifier}`);
      const fake = new vm.SyntheticModule(Object.keys(values), function () {
        for (const [key, value] of Object.entries(values)) this.setExport(key, value);
      }, { context });
      return fake;
    });
    return module;
  }
  const module = await load(new URL('../lib/index.js', import.meta.url).href);
  await module.evaluate();
  return module.namespace;
}

export function fakeSubprocess({ stderr = '', stdout = '', exitCode = 1, done, onSpawn } = {}) {
  let calls = 0;
  return {
    get calls() { return calls; },
    spawn(options) {
      calls++;
      onSpawn?.(options);
      return {
        done: done ?? Promise.resolve({ exitCode, signal: exitCode === null ? 'SIGTERM' : null }),
        collected: {
          stdout: { readFrom: () => ({ text: stdout }) },
          stderr: { readFrom: () => ({ text: stderr }) }
        }
      };
    }
  };
}

export function testConfig() {
  return { egoBin: '/fake/ego-browser.mjs', chromePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    defaultSpace: 'test-owned-space', maxOutputBytes: 4096, graceMs: 100,
    residentExecutor: false, egoCliArgs: '', chromeArgs: '', isolateSpaces: true,
    spaceTracker: { resetToName: () => { throw new Error('stale space must not reset'); } } };
}
